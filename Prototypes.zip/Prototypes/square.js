/*function Square(length){
    this.length = length;
    this.getArea = function(){
        return this.length * this.length;
    }
}*/

function Square(length){
    this.length = length;
}
Square.prototype.getCircumference =function(){
    return 4 * this.length;
}

Square.prototype.getArea = function(){
    return this.length * this.length;
}


module.exports = Square;